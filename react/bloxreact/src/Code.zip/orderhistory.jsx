import React, { useState, useEffect } from 'react';
import axios from 'axios';

const OrderHistory = ({ category }) => {
    const [orders, setOrders] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchOrders = async () => {
            try {
                const response = await axios.get(`http://127.0.0.1:5000/orders/history?category=${category}`, {
                    headers: {
                        'Authorization': `Bearer ${localStorage.getItem('token')}`,  
                    },
                });
                setOrders(response.data);
                setLoading(false);
            } catch (error) {
                console.error('Error fetching orders', error);
            }
        };

        fetchOrders();
    }, [category]);

    if (loading) {
        return <div>Loading...</div>;
    }

    return (
        <div>
            {orders.length === 0 ? (
                <div>No orders found for this category</div>
            ) : (
                orders.map((order) => (
                    <div key={order.id} className="order-item">
                        <h3>{order.product_name}</h3>
                        <p>Category: {order.category}</p>
                        <p>Status: {order.order_status}</p>
                        <p>Total: {order.total_price}</p>
                        <button>Beli Lagi</button>
                    </div>
                ))
            )}
        </div>
    );
};

export default OrderHistory;
